$(document).ready(function() {
    const apiUrl = "https://fakestoreapi.com/products/category/furniture"; // Ganti dengan API furnitur yang sesuai

    $.get(apiUrl, function(data) {
        let productsHtml = '';
        data.forEach(product => {
            productsHtml += `
                <div class="product-card">
                    <img src="${product.image}" alt="${product.title}" style="width: 100%; height: 200px; object-fit: cover;">
                    <h3>${product.title}</h3>
                    <p>${product.description}</p>
                    <p><strong>$${product.price}</strong></p>
                    <button class="add-to-cart">Tambah ke Keranjang</button>
                </div>
            `;
        });
        $('.product-grid').html(productsHtml);
    });
});
